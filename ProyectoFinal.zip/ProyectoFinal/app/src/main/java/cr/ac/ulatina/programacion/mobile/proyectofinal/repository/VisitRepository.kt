package cr.ac.ulatina.programacion.mobile.proyectofinal.repository

import cr.ac.ulatina.programacion.mobile.proyectofinal.database.VisitDao
import cr.ac.ulatina.programacion.mobile.proyectofinal.model.Visit
import kotlinx.coroutines.flow.Flow

class VisitRepository(private val visitDao: VisitDao) {

    val allVisits: Flow<List<Visit>> = visitDao.getAllVisits()

    suspend fun insert(visit: Visit) {
        visitDao.insertVisit(visit)
    }

    suspend fun getAllVisitsList(): List<Visit> {
        // Implementation if needed
        return emptyList()
    }
}
