package cr.ac.ulatina.programacion.mobile.proyectofinal.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import cr.ac.ulatina.programacion.mobile.proyectofinal.model.Visit

@Database(entities = [Visit::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun visitDao(): VisitDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "clarity_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
