package cr.ac.ulatina.programacion.mobile.proyectofinal.database;

import androidx.annotation.NonNull;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.room.util.DBUtil;
import androidx.room.util.TableInfo;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class AppDatabase_Impl extends AppDatabase {
  private volatile VisitDao _visitDao;

  @Override
  @NonNull
  protected SupportSQLiteOpenHelper createOpenHelper(@NonNull final DatabaseConfiguration config) {
    final SupportSQLiteOpenHelper.Callback _openCallback = new RoomOpenHelper(config, new RoomOpenHelper.Delegate(1) {
      @Override
      public void createAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `visits` (`id` TEXT NOT NULL, `fecha` INTEGER NOT NULL, `operador` TEXT NOT NULL, `piscina` TEXT NOT NULL, `cloroInicial` REAL NOT NULL, `phInicial` REAL NOT NULL, `alcalinidadInicial` REAL NOT NULL, `durezaCalcica` REAL NOT NULL, `acidoCianuro` REAL NOT NULL, `notas` TEXT NOT NULL, PRIMARY KEY(`id`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '2ba633290e070b0e924cbcecabbdd446')");
      }

      @Override
      public void dropAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS `visits`");
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onDestructiveMigration(db);
          }
        }
      }

      @Override
      public void onCreate(@NonNull final SupportSQLiteDatabase db) {
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onCreate(db);
          }
        }
      }

      @Override
      public void onOpen(@NonNull final SupportSQLiteDatabase db) {
        mDatabase = db;
        internalInitInvalidationTracker(db);
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onOpen(db);
          }
        }
      }

      @Override
      public void onPreMigrate(@NonNull final SupportSQLiteDatabase db) {
        DBUtil.dropFtsSyncTriggers(db);
      }

      @Override
      public void onPostMigrate(@NonNull final SupportSQLiteDatabase db) {
      }

      @Override
      @NonNull
      public RoomOpenHelper.ValidationResult onValidateSchema(
          @NonNull final SupportSQLiteDatabase db) {
        final HashMap<String, TableInfo.Column> _columnsVisits = new HashMap<String, TableInfo.Column>(10);
        _columnsVisits.put("id", new TableInfo.Column("id", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsVisits.put("fecha", new TableInfo.Column("fecha", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsVisits.put("operador", new TableInfo.Column("operador", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsVisits.put("piscina", new TableInfo.Column("piscina", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsVisits.put("cloroInicial", new TableInfo.Column("cloroInicial", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsVisits.put("phInicial", new TableInfo.Column("phInicial", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsVisits.put("alcalinidadInicial", new TableInfo.Column("alcalinidadInicial", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsVisits.put("durezaCalcica", new TableInfo.Column("durezaCalcica", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsVisits.put("acidoCianuro", new TableInfo.Column("acidoCianuro", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsVisits.put("notas", new TableInfo.Column("notas", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysVisits = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesVisits = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoVisits = new TableInfo("visits", _columnsVisits, _foreignKeysVisits, _indicesVisits);
        final TableInfo _existingVisits = TableInfo.read(db, "visits");
        if (!_infoVisits.equals(_existingVisits)) {
          return new RoomOpenHelper.ValidationResult(false, "visits(cr.ac.ulatina.programacion.mobile.proyectofinal.model.Visit).\n"
                  + " Expected:\n" + _infoVisits + "\n"
                  + " Found:\n" + _existingVisits);
        }
        return new RoomOpenHelper.ValidationResult(true, null);
      }
    }, "2ba633290e070b0e924cbcecabbdd446", "fa827878b9069cfb2988912e047ba2b4");
    final SupportSQLiteOpenHelper.Configuration _sqliteConfig = SupportSQLiteOpenHelper.Configuration.builder(config.context).name(config.name).callback(_openCallback).build();
    final SupportSQLiteOpenHelper _helper = config.sqliteOpenHelperFactory.create(_sqliteConfig);
    return _helper;
  }

  @Override
  @NonNull
  protected InvalidationTracker createInvalidationTracker() {
    final HashMap<String, String> _shadowTablesMap = new HashMap<String, String>(0);
    final HashMap<String, Set<String>> _viewTables = new HashMap<String, Set<String>>(0);
    return new InvalidationTracker(this, _shadowTablesMap, _viewTables, "visits");
  }

  @Override
  public void clearAllTables() {
    super.assertNotMainThread();
    final SupportSQLiteDatabase _db = super.getOpenHelper().getWritableDatabase();
    try {
      super.beginTransaction();
      _db.execSQL("DELETE FROM `visits`");
      super.setTransactionSuccessful();
    } finally {
      super.endTransaction();
      _db.query("PRAGMA wal_checkpoint(FULL)").close();
      if (!_db.inTransaction()) {
        _db.execSQL("VACUUM");
      }
    }
  }

  @Override
  @NonNull
  protected Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
    final HashMap<Class<?>, List<Class<?>>> _typeConvertersMap = new HashMap<Class<?>, List<Class<?>>>();
    _typeConvertersMap.put(VisitDao.class, VisitDao_Impl.getRequiredConverters());
    return _typeConvertersMap;
  }

  @Override
  @NonNull
  public Set<Class<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
    final HashSet<Class<? extends AutoMigrationSpec>> _autoMigrationSpecsSet = new HashSet<Class<? extends AutoMigrationSpec>>();
    return _autoMigrationSpecsSet;
  }

  @Override
  @NonNull
  public List<Migration> getAutoMigrations(
      @NonNull final Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> autoMigrationSpecs) {
    final List<Migration> _autoMigrations = new ArrayList<Migration>();
    return _autoMigrations;
  }

  @Override
  public VisitDao visitDao() {
    if (_visitDao != null) {
      return _visitDao;
    } else {
      synchronized(this) {
        if(_visitDao == null) {
          _visitDao = new VisitDao_Impl(this);
        }
        return _visitDao;
      }
    }
  }
}
