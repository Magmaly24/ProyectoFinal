package cr.ac.ulatina.programacion.mobile.proyectofinal.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "visits")
data class Visit(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val fecha: Long = System.currentTimeMillis(),
    val operador: String = "",
    val piscina: String = "",
    val cloroInicial: Double = 0.0,
    val phInicial: Double = 0.0,
    val alcalinidadInicial: Double = 0.0,
    val durezaCalcica: Double = 0.0,
    val acidoCianuro: Double = 0.0,
    val notas: String = ""
)
