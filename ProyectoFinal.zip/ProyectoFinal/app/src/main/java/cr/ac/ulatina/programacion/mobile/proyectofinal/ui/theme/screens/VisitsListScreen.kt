package cr.ac.ulatina.programacion.mobile.proyectofinal.ui.theme.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VisitsListScreen(viewModel: VisitViewModel) {
    val visits by viewModel.allVisits.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Visitas Guardadas",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(visits) { visit ->
                VisitItem(visit)
            }
        }
    }
}

@Composable
fun VisitItem(visit: cr.ac.ulatina.programacion.mobile.proyectofinal.model.Visit) {
    val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    val dateString = sdf.format(Date(visit.fecha))

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Fecha: $dateString", fontWeight = FontWeight.Bold)
            Text(text = "Operador: ${visit.operador}")
            Text(text = "Piscina: ${visit.piscina}")
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "Cloro: ${visit.cloroInicial}")
                Text(text = "PH: ${visit.phInicial}")
                Text(text = "Alc: ${visit.alcalinidadInicial}")
            }
        }
    }
}
