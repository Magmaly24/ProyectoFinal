package cr.ac.ulatina.programacion.mobile.proyectofinal.database;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import java.lang.Class;
import java.lang.Exception;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class VisitDao_Impl implements VisitDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Visit> __insertionAdapterOfVisit;

  public VisitDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfVisit = new EntityInsertionAdapter<Visit>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `visits` (`id`,`fecha`,`operador`,`piscina`,`cloroInicial`,`phInicial`,`alcalinidadInicial`,`durezaCalcica`,`acidoCianuro`,`notas`) VALUES (?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Visit entity) {
        statement.bindString(1, entity.getId());
        statement.bindLong(2, entity.getFecha());
        statement.bindString(3, entity.getOperador());
        statement.bindString(4, entity.getPiscina());
        statement.bindDouble(5, entity.getCloroInicial());
        statement.bindDouble(6, entity.getPhInicial());
        statement.bindDouble(7, entity.getAlcalinidadInicial());
        statement.bindDouble(8, entity.getDurezaCalcica());
        statement.bindDouble(9, entity.getAcidoCianuro());
        statement.bindString(10, entity.getNotas());
      }
    };
  }

  @Override
  public Object insertVisit(final Visit visit, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __insertionAdapterOfVisit.insert(visit);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Flow<List<Visit>> getAllVisits() {
    final String _sql = "SELECT * FROM visits ORDER BY fecha DESC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"visits"}, new Callable<List<Visit>>() {
      @Override
      @NonNull
      public List<Visit> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfFecha = CursorUtil.getColumnIndexOrThrow(_cursor, "fecha");
          final int _cursorIndexOfOperador = CursorUtil.getColumnIndexOrThrow(_cursor, "operador");
          final int _cursorIndexOfPiscina = CursorUtil.getColumnIndexOrThrow(_cursor, "piscina");
          final int _cursorIndexOfCloroInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "cloroInicial");
          final int _cursorIndexOfPhInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "phInicial");
          final int _cursorIndexOfAlcalinidadInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "alcalinidadInicial");
          final int _cursorIndexOfDurezaCalcica = CursorUtil.getColumnIndexOrThrow(_cursor, "durezaCalcica");
          final int _cursorIndexOfAcidoCianuro = CursorUtil.getColumnIndexOrThrow(_cursor, "acidoCianuro");
          final int _cursorIndexOfNotas = CursorUtil.getColumnIndexOrThrow(_cursor, "notas");
          final List<Visit> _result = new ArrayList<Visit>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final Visit _item;
            final String _tmpId;
            _tmpId = _cursor.getString(_cursorIndexOfId);
            final long _tmpFecha;
            _tmpFecha = _cursor.getLong(_cursorIndexOfFecha);
            final String _tmpOperador;
            _tmpOperador = _cursor.getString(_cursorIndexOfOperador);
            final String _tmpPiscina;
            _tmpPiscina = _cursor.getString(_cursorIndexOfPiscina);
            final double _tmpCloroInicial;
            _tmpCloroInicial = _cursor.getDouble(_cursorIndexOfCloroInicial);
            final double _tmpPhInicial;
            _tmpPhInicial = _cursor.getDouble(_cursorIndexOfPhInicial);
            final double _tmpAlcalinidadInicial;
            _tmpAlcalinidadInicial = _cursor.getDouble(_cursorIndexOfAlcalinidadInicial);
            final double _tmpDurezaCalcica;
            _tmpDurezaCalcica = _cursor.getDouble(_cursorIndexOfDurezaCalcica);
            final double _tmpAcidoCianuro;
            _tmpAcidoCianuro = _cursor.getDouble(_cursorIndexOfAcidoCianuro);
            final String _tmpNotas;
            _tmpNotas = _cursor.getString(_cursorIndexOfNotas);
            _item = new Visit(_tmpId,_tmpFecha,_tmpOperador,_tmpPiscina,_tmpCloroInicial,_tmpPhInicial,_tmpAlcalinidadInicial,_tmpDurezaCalcica,_tmpAcidoCianuro,_tmpNotas);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
