package cr.ac.ulatina.programacion.mobile.proyectofinal.model

data class Usuario(
    val idUsuario: Int,
                     var nombre: String,
                     var edad: Int,
                     var cedula: String,
                     var tipoUsuario: TipoUsuario
)
enum class TipoUsuario {
    NORMAL,
    ADMIN
}