package cr.ac.ulatina.programacion.mobile.proyectofinal.ui.theme.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import cr.ac.ulatina.programacion.mobile.proyectofinal.database.AppDatabase
import cr.ac.ulatina.programacion.mobile.proyectofinal.model.Visit
import cr.ac.ulatina.programacion.mobile.proyectofinal.repository.VisitRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VisitViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: VisitRepository
    val allVisits: StateFlow<List<Visit>>

    init {
        val visitDao = AppDatabase.getDatabase(application).visitDao()
        repository = VisitRepository(visitDao)
        allVisits = repository.allVisits.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun insert(visit: Visit) = viewModelScope.launch {
        repository.insert(visit)
    }
}
