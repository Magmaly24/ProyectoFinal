package cr.ac.ulatina.programacion.mobile.proyectofinal.ui.theme.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import cr.ac.ulatina.programacion.mobile.proyectofinal.model.Visit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VisitFormScreen(viewModel: VisitViewModel) {
    var cloro by remember { mutableStateOf("") }
    var ph by remember { mutableStateOf("") }
    var alcalinidad by remember { mutableStateOf("") }
    var dureza by remember { mutableStateOf("") }
    var acido by remember { mutableStateOf("") }
    var notas by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFAFAFA))
            .padding(16.dp)
            .verticalScroll(scrollState)
    ) {
        FormField(label = "Cloro Inicial", value = cloro, onValueChange = { cloro = it })
        FormField(label = "PH Inicial", value = ph, onValueChange = { ph = it })
        FormField(label = "Alcalinidad Inicial", value = alcalinidad, onValueChange = { alcalinidad = it })
        FormField(label = "Dureza Calcica", value = dureza, onValueChange = { dureza = it })
        FormField(label = "Acido Cianuro", value = acido, onValueChange = { acido = it })
        FormField(label = "Notas", value = notas, onValueChange = { notas = it })

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val visit = Visit(
                    cloroInicial = cloro.toDoubleOrNull() ?: 0.0,
                    phInicial = ph.toDoubleOrNull() ?: 0.0,
                    alcalinidadInicial = alcalinidad.toDoubleOrNull() ?: 0.0,
                    durezaCalcica = dureza.toDoubleOrNull() ?: 0.0,
                    acidoCianuro = acido.toDoubleOrNull() ?: 0.0,
                    notas = notas,
                    operador = "Adriana Franco",
                    piscina = "Piscina Principal"
                )
                viewModel.insert(visit)
                cloro = ""; ph = ""; alcalinidad = ""; dureza = ""; acido = ""; notas = ""
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
            shape = MaterialTheme.shapes.small,
            modifier = Modifier.width(120.dp)
        ) {
            Text("Submit", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun FormField(label: String, value: String, onValueChange: (String) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(text = label, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.medium,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color.LightGray,
                unfocusedBorderColor = Color.LightGray
            )
        )
    }
}
